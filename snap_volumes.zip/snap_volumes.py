import boto3  
import collections  
import datetime

#-------------------------------------------------
# Use:
# - Create a lambda function to execute daily
# - Give it permissions to logs:*, ec2:Describe*, 
#   and ec2 snapshot actions
# - Tag each volume you want to snapshot with:
#   Backup = True
#   Retention = <days> (default is 7)
# - Create the snap_delete function that cleans
#   up old snapshots
#-------------------------------------------------
# Create boto3 client. Modify region name to suit
#-------------------------------------------------
ec = boto3.client('ec2', region_name='us-west-2')

#-------------------------------------------------
# Lambda function snap_volumes.lambda_handler
#-------------------------------------------------
def lambda_handler(event, context):  
    # List all volumes with Backup = True
    volumes = ec.describe_volumes(
        Filters=[
            {'Name': 'tag:Backup', 'Values': ['True']}
        ]
    ).get(
        'Volumes', []
    )

    print "Number of Volumes : %d" % len(volumes)

    # to_tag = collections.defaultdict(list)

    for vol in volumes:
        try:
            retention_days = [
                int(t.get('Value')) for t in vol['Tags']
                if t['Key'] == 'Retention'][0]
        except IndexError:
            # Default retention. Use Retention tag on each volume
            retention_days = 7

        vol_id = vol['VolumeId']
        for name in vol['Tags']:
            # To store the instance key value
            # key= name['Key']
            # Get volume name for the snapshot Name tag
            if name['Key'] == 'Name' :
                vol_name = name['Value']
                print "Found EBS volume %s with name %s" % (
                vol_id, vol_name)
                snap = ec.create_snapshot(
                    VolumeId=vol_id,
                    Description="Automatic Backup: " + vol_name,
                )
                print "snap %s" %snap

        # to_tag[retention_days].append(snap['SnapshotId'])

        print "Retaining snapshot %s of volume %s for %d days" % (
            snap['SnapshotId'],
            vol_id,
            retention_days,
        )
        delete_date = datetime.date.today() + datetime.timedelta(days=retention_days)
        snapshot = vol_name + str('_') + str(datetime.date.today())    # today's date
        delete_fmt = delete_date.strftime('%Y-%m-%d')   # format the date
        print "Will delete snapshot on %s" % (delete_fmt)
        #-----------------------------------------------------------------
        # name the snapshot and set DeleteOn for the snap_delete function
        #-----------------------------------------------------------------
        ec.create_tags(
        Resources=[ snap['SnapshotId'] ],
        Tags=[
            {'Key': 'DeleteOn', 'Value': delete_fmt},
            {'Key': 'Name', 'Value': snapshot },
        ])